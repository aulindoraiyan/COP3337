public class Manager extends Employee{
    private double bonus;

    public Manager(){
        super();

    }
    public Manager(String id, String name, String department, double salary, String designation){
        super(id, name, department, salary, designation);

    }
    public Manager(Manager other){
        super(other);


    }


    public  double addBonus(){
        if (getDesignation().equalsIgnoreCase("Manager")) {
            bonus = getSalary() + 300.0;
        }

        return bonus;

    }

    public String display(){
        return (super.toString() + " \n" + "Salary after adding the bonus is : " + addBonus() + "\n " );
    }

}
