public class Clerk extends Employee{
    private double bonus;

    public Clerk(){
        super();

    }
    public Clerk(String id, String name, String department, double salary, String designation){
        super(id, name, department, salary, designation);

    }
    public Clerk(Clerk other){
        super(other);


    }


    public  double addBonus(){
        if (getDesignation().equalsIgnoreCase("Clerk")) {
            bonus = getSalary() + 100.0;
        }

        return bonus;

    }

    public String display(){
        return super.toString() + " \n" + "Salary after adding the bonus is : " + addBonus() + "\n";
    }
}
