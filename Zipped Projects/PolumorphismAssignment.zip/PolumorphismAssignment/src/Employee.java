public class Employee {
    private String id;
    private String name;
    private String department;
    private String designation;
    private double salary;

    public Employee(){
        this("No id yet", "No name yet", "No Department yet", 0.0, "No designation");
    }
    public Employee(String id, String name, String department, double salary, String designation){
        setId(id);
        setName(name);
        setDepartment(department);
        setSalary(salary);
        setDesignation(designation);
    }
    public Employee(Employee other){
        setId(other.id);
        setName(other.name);
        setDepartment(other.department);
        setSalary(other.salary);
        setDesignation(other.designation);
    }

    public String getId() {

        return id;
    }

    public void setId(String id) {
        if(id == null){
            System.out.println("Not valid id");
            System.exit(0);
        }
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null){
            System.out.println("Enter valid name");
            System.exit(0);
        }
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        if (department == null){
            System.out.println("Enter valid department");
            System.exit(0);
        }
        this.department = department;
    }

    public double getSalary() {
        return salary;
    }


    public void setSalary(double salary) {
        if(salary <= 0.0){
            System.out.println("Enter valid Salary");
            System.exit(0);
        }
        this.salary = salary;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    @Override
    public String toString() {
        return "Employee ID : " + id + '\n' +
                "Employee Name : " + name + '\n' +
                "Department Name : " + department + '\n' +
                "Salary : " + salary + '\n' +
                "Designation : " + designation
        ;
    }
    public boolean equals(Employee other){
        return (
                getId().equals(other.getId()) && getName().equals(other.getName()) && getDepartment().equals(other.getDepartment()) &&
                        getSalary() == other.getSalary() && getDesignation().equals(other.getDesignation())
                );
    }

    public double addBonus(){
        return getSalary() + 200;
    }

    public double calculateDeduction(int daysPresent){
        int totalDays = 20;
        double perDaySalary = getSalary() / totalDays;
        int absent = totalDays - daysPresent;
        double deduction = absent * perDaySalary;

        return deduction;
    }
}
