import java.util.Scanner;

public class main {
    public static void main(String args[]){
        Scanner scan = new Scanner(System.in);
        Manager m1 = new Manager("E001", "Mark", "HR", 15000.0, "manager");
        Manager m2 = new Manager("E012", "Peter", "R&D", 15000.0, "manager");

        Clerk c1 = new Clerk("E056", "Samual", "Accounts", 10000.0, "Clerk");
        Clerk c2 = new Clerk("E089", "George", "Finance", 12000.0, "Clerk");

        System.out.println(m1.display());
        System.out.println(m2.display());
        System.out.println(c1.display());
        System.out.println(c2.display());

        if(m1.getDesignation() != c1.getDesignation()){
            System.out.println(m1.getName() + " and " + c1.getName() + " have different Designation");
        }
        else{
            System.out.println(m1.getName() + " and " + c1.getName() + " have same Designation");

        }
        System.out.println();




        Employee[] employees = {m1, m2, c1, c2};
        int[] daysPresent = new int[employees.length];

        for(int i = 0; i < employees.length; i++){
            System.out.println("Enter the number of days Employee " + employees[i].getId() + " is Present out of 20: ");
            daysPresent[i] = scan.nextInt();

        }
        System.out.println("Employee ID\t\tPresent\tAbsent\tDeductions");
        double totalDeduction = 0.0;
        for(int i = 0; i < employees.length; i++){
            double deduction = employees[i].calculateDeduction(daysPresent[i]);
            totalDeduction += deduction;

            System.out.println(employees[i].getId() + "\t\t\t  " + daysPresent[i] + "\t\t  " + (20 - daysPresent[i]) +
                    "\t  " + deduction);


        }
        System.out.println("Total Deduction : " + totalDeduction);



//        int[] arrayDeduction = new int[2];
//        int absent;
//
//        for(int i = 0; i < arrayDeduction.length; i++){
//            System.out.println("Enter the number of days " + m1);
//        }
    }

}
