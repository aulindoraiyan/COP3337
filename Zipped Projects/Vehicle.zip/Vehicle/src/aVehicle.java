import java.util.Scanner;
public class aVehicle {
    public static void main (String[] args){

        Scanner keyboard = new Scanner(System.in);
       

        Vehicle aCar = new Vehicle( );

        System.out.println("Enter tank size of your car: " );
        aCar.setTankSize(keyboard.nextInt());

        System.out.println("Enter the efficiency of the car: " );
        aCar.setEfficiency(keyboard.nextDouble());

        System.out.println(aCar);

        aCar.availableTankCapacity();

        System.out.println();
        System.out.println("How much gallons of Petrol to add: ");
        aCar.setMorePatrol(keyboard.nextDouble());
        aCar.addPetrol();

        aCar.driveTo();



    }

}
