public class Vehicle {
    private int tankSize;
    private double efficiency;
    private double fuelInTank;
    private double morePatrol;

    public Vehicle(){
        tankSize = 0;
        efficiency = 0.0;
        fuelInTank = 0.0;
        morePatrol = 0.0;

    }
    public  Vehicle(int tankSize, double efficiency, double fuelInTank, double morePatrol){
        this.tankSize = tankSize;
        this.efficiency = efficiency;
        this.fuelInTank = fuelInTank;
        this.morePatrol = morePatrol;
    }

    public Vehicle(Vehicle aVehicle){
        this(aVehicle.tankSize, aVehicle.efficiency, aVehicle.fuelInTank, aVehicle.morePatrol);
    }

    public int getTankSize() {
        return tankSize;
    }

    public void setTankSize(int tankSize) {
        this.tankSize = tankSize;
    }

    public double getEfficiency() {
        return efficiency;
    }

    public void setEfficiency(double efficiency) {
        this.efficiency = efficiency;
    }

    public double getFuelInTank() {
        return fuelInTank;
    }

    public void setFuelInTank(double fuelInTank) {
        this.fuelInTank = fuelInTank;
    }

    public double getMorePatrol(){
        return morePatrol;
    }
    public void setMorePatrol(double morePatrol){
        this.morePatrol = morePatrol;
    }

    public double availableTankCapacity(){
        double remaining;
//        setFuelInTank((double)getTankSize() -getFuelInTank());
        remaining = (double)getTankSize() -getFuelInTank();
        System.out.println("Available Capacity of Tank =  " + remaining);

        return remaining;

    }
    public void addPetrol(){
        double remaining = (double)getTankSize() -getFuelInTank();


        if (remaining < getMorePatrol()){
            System.out.println("Error! Add less petrol. Not enough space");
        }
        else {
            setFuelInTank(getFuelInTank() + getMorePatrol());

            System.out.println("Adding " + getMorePatrol() + " gallons fuel to the tank.");
            System.out.println("Fuel in tank = " + getFuelInTank() );

        }
    }

    public double driveTo(){
        double distance = getEfficiency() * getFuelInTank();

        System.out.println("You can travel " + distance + " miles with available fuel.");
        return distance;
    }
    public String toString(){
        return "Fuel In Tank = " + getFuelInTank() + "\n" +
        "Total Capacity of Tank = " + (double)getTankSize() + "\n" +
        "Fuel Efficiency = " + getEfficiency();
    }




}

