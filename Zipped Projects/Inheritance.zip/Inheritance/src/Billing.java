public class Billing {
    private String pName;
    private String DocName;
    private double fee;

    public Billing(){
        this("No Patient's name", "No doctor's name", 0);
    }
    public Billing(String pName, String DocName, double fee){
        setpName(pName);
        setDocName(DocName);
        setFee(fee);
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        if(pName == null){
            System.out.println("Enter Valid Patient's name");
            System.exit(0);
        }
        this.pName = pName;
    }

    public String getDocName() {
        return DocName;
    }

    public void setDocName(String docName) {
        if(docName == null){
            System.out.println("Enter Valid Doctor's name");
            System.exit(0);
        }
        DocName = docName;
    }

    public double getFee() {
        return fee;
    }

    public void setFee(double fee) {
        this.fee = fee;
    }
    public String toString(){
        return (
                "Patient: " + getpName() + "\n" +
                        "Doctor: " + getDocName() + "\n"+
                        "Amount Due: " + getFee()

                );
    }
}
