import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
            Scanner scan = new Scanner(System.in);

            Doctor doc1 = new Doctor("Bob", new Date("December", 8, 2023), 34000, "Pediatrist", 10.5);
            Doctor doc2 = new Doctor("Susan", new Date("December", 31, 2022),450000, "Surgeon", 150.5);
            Doctor doc3 = new Doctor("Lily", new Date("December", 31, 2022), 290000, "Kidney", 95.5);
            System.out.println(doc1);
            System.out.println(doc2);
            System.out.println(doc3);



        System.out.println("\n ");
        System.out.println("**Patient Information**");
//        String docsName = doc1.getName();
        Patient p1 = new Patient("Fred", doc1.getName());
        Patient p2 = new Patient("Sally", doc2.getName());
        Patient p3 = new Patient("John", doc3.getName());

        System.out.println(p1);
        System.out.println(p2);
        System.out.println(p3);

        Billing b1 = new Billing(p1.getName(), p1.getDocName(), doc1.getFee());
        Billing b2 = new Billing(p2.getName(), p2.getDocName(), doc2.getFee());
        Billing b3 = new Billing(p3.getName(), p3.getDocName(), doc3.getFee());

        System.out.println("\n" + "*Billing Information*");
        System.out.println(b1);
        System.out.println(b2);
        System.out.println(b3);


    }
    }
